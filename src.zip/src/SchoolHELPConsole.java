import model.*;

import java.util.List;
import java.util.Scanner;

public class SchoolHELPConsole {
    private static SchoolHelp schoolHelp;
    private static Scanner sc;

    public static void main(String[] args) {
        sc = new Scanner(System.in);
        schoolHelp = new SchoolHelp();

        int choice;
        do {
            System.out.println("\n\n ====== Welcome to SchoolHELP =====");
            System.out.println("1. Register School");
            System.out.println("2. Submit Request");
            System.out.println("3. Register as Volunteer");
            System.out.println("4. View Requests");
            System.out.println("5. Submit Offer");
            System.out.println("6. Review Offers");
            System.out.println("0. Quit");
            System.out.println("");
            System.out.print("Your choice : ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    registerSchool();
                    break; //Line 5a. skipped
                case 2:
                    submitRequest();
                    break;
                case 3:
                    registerVolunteer();
                    break;
                case 4:
                    viewRequest();
                    break;
                case 5:
                    submitOffer();
                    break;
                case 6:
                    reviewOffer();
                    break;
                case 0:
                    System.out.println("Thank You");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 0);
    }

    private static boolean reviewOffer() {
        System.out.println("Review Offer");
        School school = loginAsSchoolAdmin();

        if (school == null) {
            System.out.println("Wrong credentials for School Administrator");
            return false;
        }

        System.out.println("1. View Request");
        int choice = sc.nextInt();
        sc.nextLine();

        printRequest(schoolHelp.viewRequest("SCHOOL", school.getSchoolName()));

        System.out.print("Select Request By ID: ");
        String reqId = sc.nextLine();
        TutorialRequest tr = schoolHelp.getTutorialRequestDetail(reqId);
        System.out.println("Tutorial Request Details");
        System.out.println("Description : " + tr.getDescription());
        System.out.println("List of Offering");
        List<Offer> offerList = schoolHelp.getOfferListByRequestId(tr.getRequestID());

        if (offerList.size() < 1) {
            System.out.println("Offerings is Empty");
            return false;
        }

        System.out.println("ID                    DATE          REMARK          NAME          AGE          OCCUPATION");
        offerList.forEach(offer ->
                System.out.println(offer.getOfferId()+"                    "
                        +offer.getOfferDate()+"          "
                        +offer.getRemarks()+"          "
                        +offer.getOfferStatus()+"          " // TODO tambahkan 1 field di offering, volunteer ID, get volunteer detail
                        +offer.getOfferStatus()+"          " // TODO sama kayak diatas
                        +offer.getOfferStatus()) // TODO sama kayak diatas

        );

        System.out.print("Select Offering to Accept : ");
        String offeringId = sc.nextLine();

        Offer offer = schoolHelp.getOfferDetailById(offeringId);

        schoolHelp.acceptOffer(offer, tr);

        // TODO need to handle logout

        return true;
    }

    private static void submitOffer() {
        System.out.println("Submit Offer");
        // TODO login as volunteer

        System.out.print("Enter request ID : ");
        String reqId = sc.nextLine();
        System.out.print("Enter remarks for this request : ");
        String remarks = sc.nextLine();
        schoolHelp.submitOffer(remarks, reqId);

        System.out.println("Your Offering has been submitted");
    }

    private static void viewRequest() {
        // TODO login as volunteer

        System.out.println("View Request");
        System.out.println("1. By School Name");
        System.out.println("2. By City");
        System.out.println("3. By Request Date");
        System.out.print("Your choice : ");
        int choice = sc.nextInt();
        sc.nextLine();

        switch (choice) {
            case 1:
                System.out.print("School name : ");
                String schoolName = sc.nextLine();
                printRequest(schoolHelp.viewRequest("SCHOOL", schoolName));
                break;
            case 2:
                System.out.print("City name : ");
                String city = sc.nextLine();
                printRequest(schoolHelp.viewRequest("CITY", city));
                break;
            case 3:
                System.out.print("Request date : ");
                String reqDate = sc.nextLine();
                printRequest(schoolHelp.viewRequest("REQUESTDATE", reqDate));
                break;
        }
    }

    private static boolean printRequest(List<TutorialRequest> requests) {
        if (requests.size() < 1) {
            System.out.println("Empty Request");
            return false;
        }

        System.out.println("ID                              DATE          DESCRIPTION          SCHOOL NAME          CITY");
        requests.forEach(request -> {
                    School sc = schoolHelp.getSchoolById(request.getSchoolID());
                    System.out.println(request.getRequestID() + "                    "
                            + request.getRequestDate() + "          "
                            + request.getDescription() + "          "
                            + sc.getSchoolName() + "          " +
                            sc.getCity());
                }
        );
        return true;
    }

    private static void registerVolunteer() {
        System.out.println("Register Volunteer Account");
        System.out.print("Enter username : ");
        String username = sc.nextLine();
        System.out.print("Enter password : ");
        String password = sc.nextLine();
        System.out.print("Enter fullname : ");
        String fullname = sc.nextLine();
        System.out.print("Enter email : ");
        String email = sc.nextLine();
        System.out.print("Enter phone : ");
        String phone = sc.nextLine();
        System.out.print("Enter occupation : ");
        String occupation = sc.nextLine();
        System.out.print("Enter position (yyyy-MM-dd): ");
        String dob = sc.nextLine();

        schoolHelp.createNewVolunteer(username, password, fullname, email, phone, occupation, dob);
    }

    private static School loginAsSchoolAdmin() {
        System.out.println("Login as School Administrator");
        System.out.print("Enter username : ");
        String username = sc.nextLine();
        System.out.print("Enter password : ");
        String password = sc.nextLine();
        System.out.println();

        School school = schoolHelp.loginAsSchoolAdmin(username, password);
        return school;
    }

    private static void submitRequest() {
        School school = loginAsSchoolAdmin();

        if (school == null) {
            System.out.println("Wrong credentials for School Administrator");
            return;
        }

        System.out.println("Please Input for Request Details");
        System.out.println("1. Tutorial Request");
        System.out.println("2. Resource Request");
        System.out.print("Your choice : ");
        String choice = sc.nextLine();

        switch (choice) {
            case "1":
                createTutorialRequest(school.getSchoolID());
            case "2":
                // TODO (createResourceRequest)
        }

    }

    private static void createTutorialRequest(String schoolId) {
        System.out.println("Please Input for Tutorial Request Details");
        System.out.print("Enter description : ");
        String desc = sc.nextLine();
        System.out.print("Enter proposed date (yyyy-MM-dd) : ");
        String propDate = sc.nextLine();
        System.out.print("Enter proposed date (hh:mm) : ");
        String propTime = sc.nextLine();
        System.out.print("Enter student level : ");
        String studentLevel = sc.nextLine();
        System.out.print("Enter number of expected students : ");
        int numStudents = sc.nextInt();
        sc.nextLine();

        schoolHelp.submitNewTutorialRequest("NEW", desc, schoolId, propDate,
                propTime, studentLevel, numStudents);
    }

    private static void registerSchool() {
        System.out.println("Login as SchoolHELP Administrator ");
        System.out.print("Enter username : ");
        String username = sc.nextLine();
        System.out.print("Enter password : ");
        String password = sc.nextLine();
        System.out.println();

        if (!schoolHelp.loginAsAdmin(username, password)) {
            System.out.println("Wrong credentials for SchoolHELP Administrator");
            return;
        }

        System.out.println("Please Input School Detail");
        System.out.print("Enter school name : ");
        String schoolName = sc.nextLine();
        System.out.print("Enter school address : ");
        String schoolAddress = sc.nextLine();
        System.out.print("Enter school city : ");
        String schoolCity = sc.nextLine();
        System.out.println();

        // Check if school already exist or not. Null mean school is not exist yet. Then create new school
        // If school in not null, mean the school already exist, then force to create School Admin Account
        School existSchool = schoolHelp.isSchoolExist(schoolName, schoolAddress, schoolCity);
        if (existSchool == null) {
            School newSchool = schoolHelp.createNewSchool(schoolName, schoolAddress, schoolCity);
            createSchoolAdmin(newSchool.getSchoolID());
        } else {
            createSchoolAdmin(existSchool.getSchoolID());
        }
    }

    private static void createSchoolAdmin(String schoolId) {
        System.out.println("Create School Administrator Account");
        System.out.print("Enter username : ");
        String schoolAdminUsername = sc.nextLine();
        System.out.print("Enter password : ");
        String schoolAdminPassword = sc.nextLine();
        System.out.print("Enter fullname : ");
        String schoolAdminFullname = sc.nextLine();
        System.out.print("Enter email : ");
        String schoolAdminEmail = sc.nextLine();
        System.out.print("Enter phone : ");
        String schoolAdminPhone = sc.nextLine();
        System.out.print("Enter staff ID : ");
        String schoolAdminStaffId = sc.nextLine();
        System.out.print("Enter position : ");
        String schoolAdminPosition = sc.nextLine();

        schoolHelp.createSchoolAdmin(schoolAdminUsername, schoolAdminPassword, schoolAdminFullname, schoolAdminEmail,
                schoolAdminPhone, schoolAdminStaffId, schoolAdminPosition, schoolId);

    }
}